package compiler.lib;

public abstract class TypeNode extends Node {

}
