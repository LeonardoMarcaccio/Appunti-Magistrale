package compiler.exc;

public class VoidException extends RuntimeException {

	private static final long serialVersionUID = 1L;

}
